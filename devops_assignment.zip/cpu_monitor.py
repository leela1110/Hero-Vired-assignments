
import psutil
import time

def monitor_cpu(threshold=80):
    print("Monitoring CPU usage...")
    try:
        while True:
            usage = psutil.cpu_percent(interval=1)
            if usage > threshold:
                print(f"⚠️  Alert! CPU usage exceeds threshold: {usage}%")
    except KeyboardInterrupt:
        print("Stopped by user.")
    except Exception as e:
        print(f"Error: {e}")

monitor_cpu()
