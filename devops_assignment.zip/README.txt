
DevOps Assignment - Python Scripts

This ZIP includes solutions for:
1. Password Strength Checker - check_password.py
2. CPU Usage Monitor - cpu_monitor.py
3. Configuration File Parser - config_parser.py with config.ini

Instructions:
- Run each script using `python script_name.py`
- Make sure you have `psutil` installed for cpu_monitor.py:
  pip install psutil

Submit this repository as per Vlearn instructions.
