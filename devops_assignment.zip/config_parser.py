
import configparser
import json

def parse_config_file(config_path, output_json_path):
    config = configparser.ConfigParser()
    try:
        config.read(config_path)
        data = {section: dict(config.items(section)) for section in config.sections()}
        with open(output_json_path, 'w') as json_file:
            json.dump(data, json_file, indent=4)
        print("✅ Configuration parsed and saved to JSON.")
        return data
    except FileNotFoundError:
        print("❌ Configuration file not found.")
    except Exception as e:
        print(f"Error: {e}")

parse_config_file("config.ini", "config_output.json")
